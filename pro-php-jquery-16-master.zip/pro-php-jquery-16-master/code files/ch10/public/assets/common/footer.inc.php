    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js">
    </script>
    <script src="assets/js/jquery.validDate.js"></script>
    <script src="assets/js/jquery.dateZoom.js"></script>
    <script src="assets/js/init.js"></script>
</body>

</html>